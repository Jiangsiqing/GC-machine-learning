from utils import load_json,plot_bar_fig

topnum = 20

feat_importance_list = load_json("log/xgboost_feat_importance_gridsearch.json")

x_list_ori = [x[0] for x in feat_importance_list][:topnum]
print("top {} features:\n{} ".format(topnum,x_list_ori))
x_list = list(range(len(x_list_ori)))
y_list_ori = [x[1] for x in feat_importance_list]
y_sum = sum(y_list_ori)
y_list = [float(x)/y_sum for x in y_list_ori][:topnum]


ylabel="relative importance"
title = "feature importance"
bar_fig_path = "log/xgboost_feature_importance_top"+str(topnum)+".png"
plot_bar_fig(x_list,y_list,ylabel,title,bar_fig_path,xlabel=None)

tp=1657
fp=144
tn=24
fn=16
p = tp/(tp+fp)
r=tp/(tp+fn)
f1=(2*p*r)/(p+r)
print(f1)

tn=1662
fn=151
tp=17
fp=11
p = tp/float(tp+fp)
r=tp/float(tp+fn)
f1=(2*p*r)/float(p+r)
print(f1)