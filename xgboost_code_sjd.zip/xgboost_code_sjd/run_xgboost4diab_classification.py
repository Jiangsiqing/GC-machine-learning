from xgboost_wrapper import XGBoostWrapper
import pandas as pd
import os
import argparse
import numpy as np
import Const
from utils import save_json
import copy

def train(xgb_model,label_column,param,param_fit,model_save_path,metric_save_path,feat_importance_save_path):
    print("train, param:\n{}\n , param_fit:\n{}\n".format(param,param_fit))
    xgb_model.train_xgboost(param,param_fit)

    ### importance
    print("analyze feature importance....")
    feature_list = list(xgb_model.total_trainset.columns.tolist())
    feature_list.remove(label_column)
    feature_importance_list = [[x, y] for x, y in zip(feature_list, xgb_model.model.feature_importances_)]
    feature_importance_list = sorted(feature_importance_list, key=lambda x: x[1], reverse=True)
    for feature, importance in feature_importance_list:
        print('{}: {}'.format(feature, importance))
    feature_importance_list_to_save = [[x[0],float(x[1])] for x in feature_importance_list]
    save_json(output=feature_importance_list_to_save, output_path=feat_importance_save_path)

    ### acc
    print("analyze accuracy.....")
    cm = xgb_model.compute_testset_accuracy(metric_save_path)

    labels = ['predicted class ' + str(x) for x in xgb_model.class_names]
    df = pd.DataFrame.from_records(cm, columns=labels)
    df.index = ['actual class ' + str(x) for x in xgb_model.class_names]
    print("=====\n",df,"\n======\n")

    cm_percentage = np.asarray(cm, dtype=np.float32)
    for row in range(cm_percentage.shape[0]):
        cm_percentage[row] = (cm_percentage[row] * 100) / np.sum(cm_percentage[row])
    cm_percentage = cm_percentage.flatten()
    cm_percentage = [round(num, 2) for num in cm_percentage.tolist()]
    cm_percentage = np.asarray(cm_percentage).reshape(Const.num_class,Const.num_class).tolist()
    labels = ['predicted class ' + str(x) for x in xgb_model.class_names]
    df = pd.DataFrame.from_records(cm_percentage, columns=labels)
    df.index = ['actual class ' + str(x) for x in xgb_model.class_names]
    print("=====\n",df,"\n======\n")

    xgb_model.model.save_model(model_save_path)



def grid_search(xgb_model,param_dist,param_fit,gpu_id,param2gridsearch,model_save_path,metric_save_path,feat_importance_save_path,grid_n_jobs):
    train_param_dist = copy.deepcopy(param_dist)
    # param2gridsearch = {'max_depth':range(3,10,2), 'min_child_weight':range(3,7,2), 'n_estimators':range(80, 120, 10)}

    print("begin grid_search...")

    train_param_dist.update({ 'gpu_id': gpu_id})
    # print("after update with grid_param_dist, train_param_dist:\n", train_param_dist)

    gsearch = xgb_model.grid_search_for_xgboost_params(param2gridsearch, train_param_dist,grid_n_jobs)
    print("gsearch.best_params_:\n", gsearch.best_params_)
    print("gsearch.best_estimator_:\n", gsearch.best_estimator_)
    print("gsearch.best_score_:\n", gsearch.best_score_)
    print("finish grid_search...")

    print("use best param to train...")
    train_param_dist.update(gsearch.best_params_)
    print("after update with best param, train_param_dist:\n", train_param_dist)
    print("begin train")

    train(xgb_model, label_column, train_param_dist,param_fit, model_save_path, metric_save_path, feat_importance_save_path)

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description=' ')
    parser.add_argument('--mode', '-m',type=str, default='grid', help='grid for gridsearch, train for train')
    parser.add_argument('--dataoversample','-ov', type=bool, default=False, help='True to use oversampled train data')
    opt = parser.parse_args()

    if not os.path.exists("model"):
        print("makedirs model")
        os.makedirs("model")
    if not os.path.exists("log"):
        print("makedirs log")
        os.makedirs("log")

    root_data_dir = '/data/sjd/'
    label_column = 'has_diab'
    if opt.dataoversample:
        save_csv_name_with_label_delete4txtvar_shuffled_train = '20180531and20171025_withlabel_delete4txtvar_shuffledtrain_trts_ratio0.7_oversample.csv'
        print("dataoversample: ",opt.dataoversample)
        print("save_csv_name_with_label_delete4txtvar_shuffled_train:\n ",save_csv_name_with_label_delete4txtvar_shuffled_train)
    else:
        save_csv_name_with_label_delete4txtvar_shuffled_train= '20180531and20171025_withlabel_delete4txtvar_shuffledtrain_trts_ratio0.7.csv'
        print("dataoversample: ",opt.dataoversample)
        print("save_csv_name_with_label_delete4txtvar_shuffled_train:\n ",save_csv_name_with_label_delete4txtvar_shuffled_train)

    save_csv_name_with_label_delete4txtvar_shuffled_test= '20180531and20171025_withlabel_delete4txtvar_shuffledtest_trts_ratio0.7.csv'
    save_data_path_train = os.path.join(root_data_dir,save_csv_name_with_label_delete4txtvar_shuffled_train)
    save_data_path_test = os.path.join(root_data_dir,save_csv_name_with_label_delete4txtvar_shuffled_test)

    xgb_n_jobs = 1
    grid_gpu_id = 4
    grid_n_jobs = 5

    grid_id = 1


    if grid_id == 1:
        train_param_dist = {'max_depth': 3, 'learning_rate': 0.1, 'n_estimators': 100, 'objective': 'binary:logistic',
                            'booster': 'gbtree', 'n_jobs': xgb_n_jobs, 'missing': Const.missing_value, 'scale_pos_weight ': 1,
                            'gpu_id': 4,'max_bin': 16, 'tree_method': 'gpu_hist','gamma':0,'subsample':1,
                            'colsample_bytree':0.8,'colsample_bylevel':1,'max_delta_step':0,'lambda':0,'alpha':0,
                            'random_state':Const.random_state}
        param2gridsearch = {'max_depth': range(1, 50, 2), 'min_child_weight': range(1, 50, 2),
                            'n_estimators': range(50, 5000, 10)}


    param_fit = {'early_stopping_rounds': 30, 'eval_metric': "auc"}


    xgb_model = XGBoostWrapper(save_data_path_train,save_data_path_test, label_column)


    if opt.mode == "grid":


        model_save_path = 'model/xgboost_model_ov' +str(opt.dataoversample)+"_g_"+str(grid_id)+ "_gridsearch"
        metric_save_path = 'log/xgboost_metric_ov' +str(opt.dataoversample)+"_g_"+str(grid_id)+  "_gridsearch.json"
        feat_importance_save_path = 'log/xgboost_feat_importance_ov' +str(opt.dataoversample)+"_g_"+str(grid_id)+  "_gridsearch.json"
        grid_search(xgb_model,train_param_dist,param_fit,grid_gpu_id,param2gridsearch,model_save_path,metric_save_path,
                    feat_importance_save_path,grid_n_jobs)



    elif opt.mode=="train":
        print("begin train")
        model_save_path = 'model/xgboost_model_ov' +str(opt.dataoversample)+ "_only_train"
        metric_save_path = 'log/xgboost_metric_ov' +str(opt.dataoversample)+  "_only_train.json"
        feat_importance_save_path = 'log/xgboost_feat_importance_ov' +str(opt.dataoversample)+ "_only_train.json"
        train(xgb_model, label_column, train_param_dist,model_save_path,metric_save_path,feat_importance_save_path)

