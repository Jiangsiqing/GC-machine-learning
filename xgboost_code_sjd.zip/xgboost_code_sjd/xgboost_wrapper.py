import pandas as pd
from xgboost import XGBClassifier
from sklearn.model_selection import KFold, GridSearchCV
from sklearn.metrics import accuracy_score, confusion_matrix
from utils import *
import Const
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import train_test_split

class XGBoostWrapper(object):
    def __init__(self, save_data_path_train,save_data_path_test,
                 label_column):
        # self.raw_df = pd.read_csv(data_dir, encoding='utf-8').drop(['Unnamed: 0'], axis=1)
        self.total_trainset = pd.read_csv(save_data_path_train,
                                    encoding='utf-8', low_memory=False)
        self.total_testset = pd.read_csv(save_data_path_test,
                                    encoding='utf-8', low_memory=False)
        self.label_column = label_column
        # self.train_test_ratio = train_test_ratio

        self.prepare_datasets()

    # def prepare_datasets(self):
    #     self.class_names = self.raw_df[self.label_column].unique().tolist()
    #     self.class_names = sorted(self.class_names, key = lambda x: x)
    #     trainsets = []
    #     self.testsets_chunk_list = []
    #     for i in range(len(self.class_names)):
    #         class_data = self.raw_df[self.raw_df[self.label_column] == self.class_names[i]]
    #         class_data = shuffle(class_data)
    #         num_trainset_data = int(len(class_data) * self.train_test_ratio)
    #         trainsets.append(class_data.iloc[:num_trainset_data, :])
    #         self.testsets_chunk_list.append(class_data.iloc[num_trainset_data:, :])
    #     self.total_trainset = pd.concat(trainsets, ignore_index=True)
    #     self.total_testset = pd.concat(self.testsets_chunk_list, ignore_index=True)

    def prepare_datasets(self):
        self.class_names = self.total_testset[self.label_column].unique().tolist()
        self.class_names = sorted(self.class_names, key = lambda x: x)
        # trainsets = []
        self.testsets_chunk_list = []
        for i in range(len(self.class_names)):
            class_data = self.total_testset[self.total_testset[self.label_column] == self.class_names[i]]
            # class_data = shuffle(class_data)
            # num_trainset_data = int(len(class_data) * self.train_test_ratio)
            # trainsets.append(class_data.iloc[:num_trainset_data, :])
            self.testsets_chunk_list.append(class_data)
        # self.total_trainset = pd.concat(trainsets, ignore_index=True)
        # self.total_testset = pd.concat(self.testsets_chunk_list, ignore_index=True)
        
    def grid_search_for_xgboost_params(self, param_test,param_dist,grid_n_jobs):
        # param_dist = {'objective': 'multi:softprob', 'booster': 'gbtree', 'n_jobs': 1, 'missing': -1}

        y_train = self.total_trainset[self.label_column]
        X_train = self.total_trainset.drop([self.label_column], axis=1)

        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=Const.random_state)

        if param_test is not None:
            # gsearch = GridSearchCV(estimator=XGBClassifier(**param_dist), param_grid=param_test, scoring='accuracy', n_jobs=5, iid=False, cv=5)
            # gsearch = GridSearchCV(estimator=XGBClassifier(**param_dist), param_grid=param_test, scoring='accuracy', n_jobs=5, iid=False, cv=cv)
            gsearch = GridSearchCV(estimator=XGBClassifier(**param_dist), param_grid=param_test, scoring='roc_auc', n_jobs=grid_n_jobs,pre_dispatch=grid_n_jobs*2, iid=False, cv=cv)
            gsearch.fit(X_train, y_train)
            # print ("gsearch.best_params_:\n",gsearch.best_params_)
            return gsearch
        else:
            raise ValueError('must input param test dict to perform grid search')

    def train_xgboost(self, param_dist=None,param_fit=None):
        if param_dist is None:
            # param_dist = {'max_depth': 3, 'learning_rate': 0.1, 'n_estimators': 100, 'objective': 'multi:softprob',
            #               'booster': 'gbtree', 'n_jobs': 1, 'missing': -1, 'scale_pos_weight ': 10}

            # 二分类，objective用binary:logistic
            param_dist = {'max_depth': 3, 'learning_rate': 0.1, 'n_estimators': 100, 'objective': 'binary:logistic',
                          'booster': 'gbtree', 'n_jobs': 1, 'missing': "NAN", 'scale_pos_weight ': 10}
        if param_fit is None:
            param_fit = {'early_stopping_rounds': 30, 'eval_metric': "auc"}

        # split data into X and y
        y_train = self.total_trainset[self.label_column]
        X_train = self.total_trainset.drop([self.label_column], axis=1)

        model = None
        train_splited_x, valid_splitd_x, train_splitd_y, valid_splitd_y \
            = train_test_split(X_train, y_train, test_size=0.3, stratify = y_train[self.label_column],
                                                              random_state = Const.random_state)

        model = XGBClassifier(**param_dist).fit(train_splited_x, train_splitd_y,
                                verbose=False, eval_set=[(valid_splitd_x, valid_splitd_y)],**param_fit)


        # kf = KFold(n_splits=5, shuffle=True)
        # for train_index, val_index in kf.split(X_train):
        #     # print("train_index:{}  type(train_index):{}".format(train_index,type(train_index)))
        #     # print("val_index:{}  type(val_index):{}".format(val_index,type(val_index)))
        #     model = XGBClassifier(**param_dist).fit(X_train.iloc[train_index], y_train.iloc[train_index])
        #     val_predictions = model.predict(X_train.iloc[val_index], ntree_limit=self.model.best_ntree_limit)
        #     actuals = y_train.iloc[val_index]
        #     cm = (confusion_matrix(actuals, val_predictions))
        #     # print('val acc {}'.format(cm[0][0]/(cm[0][0]+cm[0][1])))


        self.model = model

    def compute_testset_accuracy(self,metric_save_path):
        for class_name, testset in zip(self.class_names, self.testsets_chunk_list):
            accuracy, _ = self.compute_accuracy(testset)
            print("class %s accuracy: %.2f%%" % (class_name, accuracy * 100.0))
        accuracy, cm = self.compute_accuracy(self.total_testset,metric_save_path)
        print ("overall accuracy: %.2f%%" % (accuracy * 100.0))
        return cm
        
    def compute_accuracy(self, testset,metric_save_path=None):
        # make predictions for test data
        y_true = testset[self.label_column]
        X_test = testset.drop([self.label_column], axis=1)
        y_pred_proba_positive = self.model.predict(X_test, ntree_limit=self.model.best_ntree_limit)
        y_pred = [round(value) for value in y_pred_proba_positive]  # 用round，就是相当于用0.5的阈值，大于0.5为1，小于等于0.5为0
        # evaluate predictions
        if metric_save_path is not None:
            print("begin_get_metric...")
            get_metric(y_true, y_pred_proba_positive, y_pred, metric_save_path)
            print("finish_get_metric...")
        accuracy = accuracy_score(y_true, y_pred)
        cm = confusion_matrix(y_true, y_pred, labels = self.class_names)
        return accuracy, cm

