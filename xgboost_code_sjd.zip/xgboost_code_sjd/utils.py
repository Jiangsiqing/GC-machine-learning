import json

### 使用服务器绘图
import matplotlib as mpl
mpl.use('Agg')
###

import matplotlib.pyplot as plt

def load_json(path):
    with open(path, 'r', encoding='utf-8') as json_file:
        aa = json_file.readlines()[0]
        output = json.loads(aa)
    return output

def plot_bar_fig(x_list,y_list,ylabel,title,bar_fig_path,xlabel=None):
    # 条形图
    # 导入绘图模块

    # # 中文乱码处理
    # plt.rcParams["font.sans-serif"] = ['Microsoft YaHei']
    # plt.rcParams['axes.unicode_minus'] = False



    # 绘图
    plt.bar(range(len(y_list)), y_list, align='center', color='steelblue', alpha=0.8)
    # 添加轴标签
    plt.ylabel(ylabel)
    # 添加标题
    plt.title(title)
    # 添加刻度标签
    plt.xticks(range(len(y_list)), x_list)
    # 设置y轴的范围
    plt.ylim([0, 1])


    # 显示图形
    plt.savefig(bar_fig_path)


def plot_fig(x,y,xlabel,ylabel,fig_save_path,auc=None):
    plt.figure(figsize=(10, 10))
    lw = 2
    if auc is not None:
        plt.plot(x, y, color='darkorange',
                 lw=lw, label='ROC curve (area = %0.2f)' % auc)  # 假正率为横坐标，真正率为纵坐标做曲线
    else:
        plt.plot(x, y, color='darkorange',lw=lw)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')  # 画对角线y=x
    plt.xlim([0.0, 1.0])  # 坐标值范围
    plt.ylim([0.0, 1.05])
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    # plt.title('Receiver operating characteristic example')
    if auc is not None:
        plt.legend(loc="lower right")  # 显示label的位置
    plt.savefig(fig_save_path)



def save_json( output, output_path):
    with open(output_path, 'w', encoding='utf-8') as json_file:
        json.dump(output, json_file, ensure_ascii=False)


def get_metric( y_true, y_pred_proba_positive, y_pred, metric_save_path):
    pr_fig_path = metric_save_path.replace(".json","_pr.png")
    roc_fig_path = metric_save_path.replace(".json","_roc.png")

    metric_json = {}
    from sklearn.metrics import precision_recall_curve
    y_scores = y_pred_proba_positive  # Target scores, can either be probability estimates of the positive class
    precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
    metric_json['precision_recall_curve_precision'] = [float(x) for x in precision.tolist()]
    metric_json['precision_recall_curve_recall'] = [float(x) for x in recall.tolist()]
    metric_json['precision_recall_curve_thresholds'] = [float(x) for x in thresholds.tolist()]


    plot_fig(x=recall, y=precision, xlabel='recall', ylabel='precision', fig_save_path=pr_fig_path,
             auc=None)

    # Compute average precision (AP) from prediction scores
    from sklearn.metrics import average_precision_score
    AP = average_precision_score(y_true, y_scores)
    print("\nAP: {}\n".format(AP))
    metric_json["AP"] = float(AP)

    # Compute Receiver operating characteristic (ROC)
    # https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html#sklearn.metrics.roc_auc_score
    from sklearn import metrics
    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_scores,
                                             pos_label=1)  # Label considered as positive and others are considered negative.

    metric_json['roc_fpr'] = [float(x) for x in fpr.tolist()]
    metric_json['roc_tpr'] = [float(x) for x in tpr.tolist()]
    metric_json['roc_thresholds'] = [float(x) for x in thresholds.tolist()]

    # Compute Area Under the Receiver Operating Characteristic Curve (ROC AUC) from prediction scores.
    from sklearn.metrics import roc_auc_score
    ROC = roc_auc_score(y_true, y_scores, 'weighted')
    print("roc_auc_score: ", ROC)
    metric_json["roc_auc_score"] = float(ROC)

    # Compute Area Under the Curve (AUC) using the trapezoidal rule
    from sklearn import metrics
    AUC = metrics.auc(fpr, tpr)
    print("auc: ", AUC)
    metric_json["AUC"] = float(AUC)
    assert AUC==ROC
    plot_fig(x=fpr, y=tpr, xlabel='False Positive Rate', ylabel='True Positive Rate', fig_save_path=roc_fig_path, auc=AUC)

    # Compute confusion matrix to evaluate the accuracy of a classification
    from sklearn.metrics import confusion_matrix
    CM = confusion_matrix(y_true, y_pred)
    print("CM: \n", CM)
    metric_json["CM"] = CM.tolist()

    # Compute the F1 score, also known as balanced F-score or F-measure
    from sklearn.metrics import f1_score
    f1 = f1_score(y_true, y_pred, average='macro')
    print("f1: ", f1)
    metric_json["f1"] = float(f1)

    save_json(output=metric_json, output_path=metric_save_path)

if __name__ =="__main__":
    bar_fig_path= 'log/barfig.png'
    plot_bar_fig(bar_fig_path)
